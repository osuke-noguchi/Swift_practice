//
//  SoundViewController.swift
//  SwiftMousouLINE
//
//  Created by Akira Suzuki on 2018/04/12.
//  Copyright © 2018年 Akira Suzuki. All rights reserved.
//

import UIKit
import AVFoundation


class SoundViewController: UIViewController {
    
    @IBOutlet var timelabel: UILabel!
    
    @IBOutlet var imageView2: UIImageView!
    
    var audioPlayer : AVAudioPlayer!
    var count = 0
    
 

    override func viewDidLoad() {
        super.viewDidLoad()

        imageView2.isHidden = true
        timelabel.isHidden = true
        if let url = Bundle.main.url(forResource: "callMusic", withExtension: "mp3") {
            do {
        audioPlayer = try AVAudioPlayer(contentsOf: url)
        audioPlayer?.play()
            } catch {
                audioPlayer = nil
            }
        } else {
    // urlがnilなので再生できない
    fatalError("Url is nil.")
            
        }
    }

    @IBAction func tap(_ sender: Any) {
        imageView2.isHidden = false
        timelabel.isHidden = false
    
        
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timercountUp), userInfo: nil, repeats: true)
    
        timelabel.text = String(count)
        
        if let url = Bundle.main.url(forResource: "callMusic", withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            } catch {
                audioPlayer = nil
            }
        
        }
    
    func timercountUp() {
        count = count + 1
      
    }
    
    
    
        func deny(_ sender: Any) {
        
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    
        func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

  
    }
}

